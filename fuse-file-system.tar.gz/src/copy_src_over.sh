# Copy entire assignment folder over (errors with username or something)
# scp -r ../../assignment3 csuser@classvm24.cs.rutgers.edu:~/

# Copy just the src folder over (MetHetLet4)
scp -r ../src csuser@classvm24.cs.rutgers.edu:~/assignment3